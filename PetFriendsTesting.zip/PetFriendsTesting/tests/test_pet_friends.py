import os
from api import PetFriends
from settings import valid_email, valid_password

#Создаем объект класса PetFriends
pf = PetFriends()

# 1 test: Получение ключа
def test_get_api_key_for_valid_user(email=valid_email, password=valid_password):
    status, result = pf.get_api_key(email, password)
    assert status == 200
    assert 'key' in result

# 2 test: Получение списка питомцев
def test_get_all_pets_with_valid_key(filter=''):
    _, auth_key = pf.get_api_key(valid_email, valid_password)
    status, result = pf.get_list_of_pets(auth_key, filter)
    assert status == 200
    assert len(result['pets']) > 0

# 3 test: Добавление питомца
def test_add_new_pet_with_valid_data(name='Ben', animal_type='camel',
                                     age='2', pet_photo='images/small_camel.jpg'):
    pet_photo = os.path.join(os.path.dirname(__file__), pet_photo)
    _, auth_key = pf.get_api_key(valid_email, valid_password)
    status, result = pf.add_new_pet(auth_key, name, animal_type, age, pet_photo)
    assert status == 200
    assert result['name'] == name

# 4 test: Удаление указанного питомца (тип результата зависит от текущего
# количества питомцев в базе данных сервера и номера удаляемого питомца!)
def test_delete_self_pet(num=0):
    #Проверяем возможность удаления питомца

    # Получаем ключ auth_key и запрашиваем список своих питомцев
    _, auth_key = pf.get_api_key(valid_email, valid_password)
    _, my_pets = pf.get_list_of_pets(auth_key, "my_pets")

    #Извлекаем из ответа количество доступных питомцев
    ListLen = len(my_pets['pets'])
    #Проверяем длину списка
    if (ListLen == 0) or (num + 1 > ListLen):
        # если спиок питомцев пустой или недостаточный, то выводим сообщение и вызываем отрицательный результат тестирования
        print("\nTesting not completed. Too few pets. Add pets and test again!")
        raise Exception("Testing not completed. Too few pets. Add pets and test again!")
    else:
        # Берём id указанного питомца из списка и отправляем запрос на удаление
        pet_id = my_pets['pets'][num]['id']
        status, _ = pf.delete_pet(auth_key, pet_id)

        # Ещё раз запрашиваем список своих питомцев
        _, my_pets = pf.get_list_of_pets(auth_key, "my_pets")

        # Проверяем что статус ответа равен 200 и в списке питомцев нет id удалённого питомца
        assert status == 200
        assert pet_id not in my_pets.values()

# 5 test: Обновление информации об указанном питомце  (тип результата зависит от текущего
# количества питомцев в базе данных сервера и номера обновляемого питомца!)
def test_update_self_pet_info(num=0, name='Мурзак', animal_type='Котюк', age=1):
    #Проверяем возможность обновления информации о питомце

    # Получаем ключ auth_key и список своих питомцев
    _, auth_key = pf.get_api_key(valid_email, valid_password)
    _, my_pets = pf.get_list_of_pets(auth_key, "my_pets")

    #Извлекаем из ответа количество доступных питомцев
    ListLen = len(my_pets['pets'])

    # Если список не пустой, то пробуем обновить его имя, тип и возраст
    if ListLen > 0:
        if (num + 1) <= ListLen:
            status, result = pf.update_pet_info(auth_key, my_pets['pets'][num]['id'], name, animal_type, age)
            # Проверяем статус ответа и имя питомца на соответствие заданному
            assert status == 200
            assert result['name'] == name
        else:
            # Если питомцев меньше требуемого количества, то выводим сообщение
            # и вызываем отрицательный результат тестирования
            print("\nTesting not completed. Too few pets. Add pets and test again!")
            raise Exception("Testing not completed. Too few pets. Add pets and test again!")
    else:
         # Если список питомцев пустой, то выводим сообщение и вызываем отрицательный результат тестирования
         print("\nTesting not completed. There are no pets at all. Add pets and test again!")
         raise Exception("Testing not completed. There are no pets at all. Add pets and test again!")

# 6 test: Добавление питомца без фото
def test_add_new_pet_simple(name='Ben', animal_type='camel',
                                     age='2'):
    _, auth_key = pf.get_api_key(valid_email, valid_password)
    status, result = pf.add_new_pet_simple(auth_key, name, animal_type, age)
    assert status == 200
    assert result['name'] == name

# 7 test: Добавление (обновление) фотографии указанному питомцу (тип результата зависит от текущего
# количества питомцев в базе данных сервера и номера обновляемого питомца!)
def test_update_pet_info_photo(num=0, pet_photo='images/cat1.jpg'):
    pet_photo = os.path.join(os.path.dirname(__file__), pet_photo)
    _, auth_key = pf.get_api_key(valid_email, valid_password)
    _, my_pets = pf.get_list_of_pets(auth_key, "my_pets")

    #Извлекаем из ответа количество доступных питомцев
    ListLen = len(my_pets['pets'])

    # Если список не пустой, то пробуем обновить фото
    if ListLen > 0:
        if (num + 1) <= ListLen:
            pet_id = my_pets['pets'][num]['id']
            status, result = pf.update_pet_photo(auth_key, pet_id, pet_photo)
            # Проверяем что статус ответа = 200 и имя питомца соответствует заданному
            assert status == 200
            assert result['name'] == my_pets['pets'][num]['name']
        else:
            # если спиок питомцев пустой, то выводим сообщение и вызываем отрицательный результат тестирования
            print("\nTesting not completed. Too few pets. Add pets and test again!")
            raise Exception("Testing not completed. Too few pets. Add pets and test again!")
    else:
         # если спиок питомцев пустой, то выводим сообщение и вызываем отрицательный результат тестирования
         print("\nTesting not completed. There are no pets at all. Add pets and test again!")
         raise Exception("Testing not completed. There are no pets at all. Add pets and test again!")

# 8 test: Получение ключа (отрицательный результат)
def test_unsuccessful_get_api_key_for_valid_user(email=valid_email, password=valid_password):
    status, result = pf.get_api_key(email, password + '1')
    assert status == 200
    assert 'key' in result

# 9 test: Добавление питомца без фото с отсутствующим типом и возрастом
def test_add_new_pet_simple(name='Ben', animal_type='', age=''):
    _, auth_key = pf.get_api_key(valid_email, valid_password)
    status, result = pf.add_new_pet_simple(auth_key, name, animal_type, age)
    assert status == 200
    assert result['name'] == name

# 10 test: Добавление питомца без фото с отрицательным возрастом
def test_add_new_pet_simple(name='Ben', animal_type='camel', age='-3'):
    _, auth_key = pf.get_api_key(valid_email, valid_password)
    status, result = pf.add_new_pet_simple(auth_key, name, animal_type, age)
    assert status == 200
    assert result['name'] == name

# 11 test: Получение списка питомцев c неправильным ключом (к ключу добавлен символ '1')
def test_get_all_pets_with_valid_key(filter=''):
    _, auth_key = pf.get_api_key(valid_email, valid_password)

    # Добавляем к ключу лишний символ
    auth_key['key'] += '1'

    status, result = pf.get_list_of_pets(auth_key, filter)
    assert status == 200
    assert len(result['pets']) > 0